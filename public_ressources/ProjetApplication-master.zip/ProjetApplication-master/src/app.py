from concurrent.futures import thread
from flask import *
from flask_bootstrap import Bootstrap
from flask_sockets import Sockets
import gevent
from geventwebsocket.handler import WebSocketHandler
import threading
from subprocess import Popen, PIPE, STDOUT
import openai
from flask_cors import CORS

openai.api_key = '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'

app = Flask(__name__)
sockets = Sockets(app)

Bootstrap(app)
app.config['BOOTSTRAP_SERVE_LOCAL'] =True
app.config['SECRET_KEY']="8d939a9d-2d7e-4261-b440-4d8706877b83"

import os.path
def mkpath(p):
    return os.path.normpath(
        os.path.join(
            os.path.dirname(__file__),p
        )
    )

@sockets.route('/websocket')
def handle_websocket(ws):
    while not ws.closed:
        message = ws.receive()
        url = message.strip()
        print(url)

        process = Popen(['python3', 'security_scan.py', url], stdout=PIPE, stderr=STDOUT, universal_newlines=True) #big probleme
        stdout, stderr = process.communicate()

        ws.send(stdout)
        if stderr is not None:
            ws.send(stderr)

def run_server():
    server = gevent.pywsgi.WSGIServer(('localhost', 25565), app, handler_class=WebSocketHandler)
    print("Socket open")
    server.serve_forever()


websocket_server_thread = threading.Thread(target=run_server)
websocket_server_thread.start()

CORS(app)
@app.route('/api/gpt', methods=['POST'])
def chat_gpt():
    message = request.get_json()['message']
    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=message,
        max_tokens=150
    )
    print(response)
    return jsonify({'response': response.choices[0].text.strip()})