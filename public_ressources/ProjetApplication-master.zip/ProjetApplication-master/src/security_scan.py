import requests
import socket
import sys
import subprocess
import threading
from flask import Flask, render_template





def check_xss_vulnerability(url):
    # XSS payloads to be injected
    print("Performing XSS vulnerability test...")

    #with open('vulnlist/xss-payload-list.txt', 'r') as file:
        #payloads = file.read().splitlines()

    payloads = [
        '<script>alert("XSS Vulnerability Found!");</script>',
        '<img src="x" onerror="alert(\'XSS Vulnerability Found!\');">',
        "-prompt(8)-",
        '-prompt(8)-',
        '<img/src/onerror=prompt(8)>',
        '<image src/onerror=prompt(8)>'
    ]
    
    #payload qui trigger une vuln
    xss_vulnerable_payloads = []
    #nombre de payload essayes
    xss_total_payloads = len(payloads)
    #nomre de payload ayant fonctionne 
    xss_vulnerabilities_found = 0

    for i, payload in enumerate(payloads, start=1):
        # Build the command to make an HTTP request with the payload
        command = f'curl -s -o /dev/null -w "%{{http_code}}" -d "{payload}" -X POST {url}'

        # Execute the command and capture the response status code
        response_code = subprocess.run(command, capture_output=True, text=True, shell=True).stdout.strip()

        # Check if the response code indicates a successful injection (e.g., 200 OK)
        if response_code == "200":
            xss_vulnerable_payloads.append(payload)
            xss_vulnerabilities_found+=1

        progression = i / xss_total_payloads * 100
        #print_progress_bar(progress)
        

    #pourcentage de vulnerabilite 
    xss_percent=(xss_vulnerabilities_found/xss_total_payloads)*100
    

    # Print the vulnerable payloads and the vulnerability information
    if len(xss_vulnerable_payloads) > 0:
        print(f"Vulnerabilities found: {xss_vulnerabilities_found}/{xss_total_payloads}")
        print("Vulnerable Payloads:")
        for payload in xss_vulnerable_payloads:
            print(payload)
    else:
        print("No XSS Vulnerability Found.")
    

def check_sql_injection_vulnerability(url):
    print("Performing SQL injection test..")
    # SQL injection payloads
    payloads = [
        "1' OR '1'='1",
        "1'; DROP TABLE users; --"
    ]
    
    #payload qui trigger une vuln
    sql_vulnerable_payloads = []
    #nombre de payload essayes
    sql_total_payloads = len(payloads)
    #nomre de payload ayant fonctionne 
    sql_vulnerabilities_found = 0

    for i, payload in enumerate(payloads, start=1):
        # Build the command to make an HTTP request with the payload
        command = f'curl -s -o /dev/null -w "%{{http_code}}" -d "param={payload}" -X POST {url}'

        # Execute the command and capture the response status code
        response_code = subprocess.run(command, capture_output=True, text=True, shell=True).stdout.strip()

        # Check if the response code indicates a successful injection (e.g., 200 OK)
        if response_code == "200":
            sql_vulnerable_payloads.append(payload)
            sql_vulnerabilities_found+=1

        progression = i / sql_total_payloads * 100
    
        
    #pourcentage de vulnerabilite 
    xss_percent=(sql_vulnerabilities_found/sql_total_payloads)*100
    # Print the vulnerable payloads and the vulnerability information

    if len(sql_vulnerable_payloads) > 0:
        print(f"Vulnerabilities found: {sql_vulnerabilities_found}/{sql_total_payloads}")
        print("Vulnerable Payloads:")
        for payload in sql_vulnerable_payloads:
            print(payload)
    else:
        print("No SQL Injection Vulnerability Found.")




""" def run_gobuster(url):
    print("Performing GoBuster test...")
    # Run Gobuster with the provided URL
    process = subprocess.Popen(['gobuster', 'dir', '-u', url, '-w', 'common.txt'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()

    # Print Gobuster output
    print("Gobuster output:")
    print(stdout.decode())




def run_wpscan(url):
    # Run WPScan with the provided URL
    print("Performing WordPress test...")
    process = subprocess.Popen(['wpscan', '--url', url], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()

    # Print WPScan output
    print("WPScan output:")
    print(stdout.decode())
 """


def check_csp(url):
    # Make an HTTP request to the URL and inspect the CSP header
    print("Performing CSP test...")
    response = subprocess.run(['curl', '-I', url], capture_output=True, text=True)
    headers = response.stdout
    csp_vuln_level = 0

    # Check if the CSP header is present and contains any unsafe directives
    if 'Content-Security-Policy' in headers:
        csp_header = headers.split('Content-Security-Policy:', 1)[1].strip()

        # Check for unsafe directives in the CSP header
        if 'unsafe-inline' in csp_header or 'unsafe-eval' in csp_header:
            print("CSP check result: Unsafe directives found in Content Security Policy.")
            csp_vuln_level=2
            #max level of csp vuln comme ca on donne un pourcentage de danger en mode arbitraire ta capte apagnan
        else:
            print("CSP check result: No issues found.")
            csp_vuln_level=0
    else:
        print("CSP check result: Content Security Policy header not found.")
        csp_vuln_level=1






def perform_security_scan(url):
    print(f"Performing security scan on URL: {url}")
    # Create a list of threads for each check

    check_xss_vulnerability(url)
    check_sql_injection_vulnerability(url)
    check_csp(url)
    #run_gobuster(url)
    #run_wpscan(url)







url = sys.argv[1]

perform_security_scan(url)
