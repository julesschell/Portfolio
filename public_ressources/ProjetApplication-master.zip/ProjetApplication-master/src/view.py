from .app import app
from flask import render_template, url_for, redirect, request, flash

@app.route('/')
def home():
    return render_template(
        "home.html"
    )

@app.route('/XSS')
def xss():
    return render_template(
        "XSS.html"
    )

@app.route('/CSP')
def csp():
    return render_template(
        "CSP.html"
    )

@app.route('/SQL')
def sql():
    return render_template(
        "SQL.html"
    )


