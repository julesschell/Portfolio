document.querySelector(document ).ready(function() {
    document.querySelector('.dropdown ul>li').click(function(){
      document.querySelector('.dropdown ul>li').each(function(){
        document.querySelector(this).removeClass('drop-selected');
      });
      document.querySelector(this).toggleClass('drop-selected');
      document.querySelector('.dropdown>span').text(document.querySelector(this).attr("val"))
    });
  });