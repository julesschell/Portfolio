function writeToTerminal(message, isError = false) {
    const terminal = document.getElementById("terminal");
    const newLine = document.createElement("div");
    newLine.classList.add(isError ? "error" : "output");
    newLine.innerText = message;
    terminal.appendChild(newLine);
    terminal.scrollTop = terminal.scrollHeight;
}

console.log = function(message) {
    writeToTerminal(message);
};

console.error = function(message) {
    writeToTerminal(message, true);
};

function startSecurityScan() {
    const urlInput = document.getElementById("url-input");
    const url = urlInput.value.trim();
    
    if (url === "") {
        writeToTerminal("Please enter a valid URL.", true);
        return;
    }

    writeToTerminal("Starting security scan...");
    writeToTerminal(`Scanning website: ${url}`);

    // Send a command to the WebSocket server to initiate the security scan
    socket.send(url);
}

// Create a WebSocket connection
const socket = new WebSocket("ws://localhost:25565/websocket"); // Replace with the appropriate WebSocket server URL

socket.onmessage = function(event) {
    const message = event.data;
    writeToTerminal(message);
};

socket.onerror = function(event) {
    writeToTerminal("WebSocket error occurred.", true);
};

socket.onclose = function(event) {
    writeToTerminal("WebSocket connection closed.", true);
};

