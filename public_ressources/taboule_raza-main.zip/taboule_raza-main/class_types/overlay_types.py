from enum import Enum

class OverlayTypes(Enum):
    DEFAULT = 1
    FIRE = 2
    DESTRUCTION = 3