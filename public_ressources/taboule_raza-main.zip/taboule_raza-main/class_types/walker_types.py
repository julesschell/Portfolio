from enum import Enum

# IntEnum: 300 - 399 range

class WalkerTypes(Enum):
    MIGRANT = 301
    PREFET = 302
    ENGINEER = 303
    IMMIGRANT = 304
    GRANARY_WORKER = 305
    FARM_WORKER = 306
    TAX_COLLECTOR = 307

    PREFET_EXTINGUISHING_FIRE = 308
