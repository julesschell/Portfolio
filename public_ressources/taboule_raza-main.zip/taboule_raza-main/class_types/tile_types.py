from enum import Enum

# IntEnum: 200 - 299 range

class TileTypes(Enum):
    GRASS = 201
    WATER = 202
    WHEAT = 203
