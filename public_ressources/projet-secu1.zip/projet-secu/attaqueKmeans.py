import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import threading
import datetime
import json
from tqdm import tqdm

class ThreadedCSVLoader(threading.Thread):
    def __init__(self, file_path, names):
        threading.Thread.__init__(self)
        self.file_path = file_path
        self.names = names

    def run(self):
        df = pd.read_csv(self.file_path, delimiter='\t', header=None, names=self.names)
        self.data = df[df['id'] != 'DEL']  # Exclure les lignes avec l'ID "DEL"

def apply_kmeans(data, n_clusters):
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(data[['latitude', 'longitude']])
    kmeans = KMeans(n_clusters=n_clusters, random_state=0)
    data['cluster'] = kmeans.fit_predict(data_scaled)
    return data, kmeans.cluster_centers_

def is_similar(value1, value2, threshold):
    """Vérifie si deux valeurs sont similaires dans les limites d'un seuil spécifié."""
    return abs(float(value1) - float(value2)) <= threshold

def apply_kmeans_and_group_by_cluster(data, n_clusters):
    data_clustered, _ = apply_kmeans(data, n_clusters)
    grouped_data = data_clustered.groupby('cluster')
    return grouped_data

# def find_matches_within_clusters(ref_grouped_data, anon_grouped_data, threshold):
#     matches = []
#     for cluster_id in ref_grouped_data.groups.keys():
#         ref_data = ref_grouped_data.get_group(cluster_id)
#         if cluster_id in anon_grouped_data.groups:
#             anon_data = anon_grouped_data.get_group(cluster_id)
#             for _, anon_row in anon_data.iterrows():
#                 for _, ref_row in ref_data.iterrows():
#                     if is_similar(anon_row['latitude'], ref_row['latitude'], threshold) and \
#                        is_similar(anon_row['longitude'], ref_row['longitude'], threshold):
#                         matches.append({'anonymized': anon_row, 'reference': ref_row})
#     return matches

class MatchFinder(threading.Thread):
    def __init__(self, ref_data, anon_data, threshold,cluster_id):
        threading.Thread.__init__(self)
        self.ref_data = ref_data
        self.anon_data = anon_data
        self.threshold = threshold
        self.cluster_id = cluster_id
        self.matches = []

    def run(self):
        total_rows = len(self.anon_data) * len(self.ref_data)
        pbar = tqdm(total=total_rows, desc=f"Traitement du cluster {self.cluster_id}")

        for _, anon_row in self.anon_data.iterrows():
            for _, ref_row in self.ref_data.iterrows():
                if is_similar(anon_row['latitude'], ref_row['latitude'], self.threshold) and \
                   is_similar(anon_row['longitude'], ref_row['longitude'], self.threshold):
                    self.matches.append({'anonymized': anon_row, 'reference': ref_row})
                pbar.update(1)
        pbar.close()

def parallel_find_matches(ref_grouped_data, anon_grouped_data, threshold):
    all_matches = []
    threads = []
    for cluster_id in ref_grouped_data.groups.keys():
        ref_data = ref_grouped_data.get_group(cluster_id)
        if cluster_id in anon_grouped_data.groups:
            anon_data = anon_grouped_data.get_group(cluster_id)
            thread = MatchFinder(ref_data, anon_data, threshold,cluster_id)
            threads.append(thread)
            thread.start()

    for thread in threads:
        thread.join()
        all_matches.extend(thread.matches)

    return all_matches

def organize_matches_by_week(matches):
    organized_data = {}
    for match in matches:
        ref_id = match['reference']['id']
        date_str = match['reference']['date']
        anon_id = match['anonymized']['id']

        try:
            date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            print(f"Erreur de format de date: {date_str}")
            continue

        year_week = f"{date_obj.isocalendar()[0]}-{date_obj.isocalendar()[1]:02d}"

        if ref_id not in organized_data:
            organized_data[ref_id] = {}
        if year_week not in organized_data[ref_id]:
            organized_data[ref_id][year_week] = []

        # Éviter les doublons d'ID anonymisés
        if anon_id not in organized_data[ref_id][year_week]:
            organized_data[ref_id][year_week].append(anon_id)

    return organized_data

def save_json(data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(data, file, indent=4)

# Configuration
reference_csv_path = 'test_dataset.csv'
anonymized_csv_path = 'test1.csv'
output_json_path = 'kmeans.json'
column_names = ['id', 'date', 'longitude', 'latitude']
n_clusters = 5  # Nombre de clusters à définir
similarity_threshold = 0.000001

# Charger les données en parallèle
thread_reference = ThreadedCSVLoader(reference_csv_path, column_names)
thread_anonymized = ThreadedCSVLoader(anonymized_csv_path, column_names)
thread_reference.start()
thread_anonymized.start()
thread_reference.join()
thread_anonymized.join()

# Convertir en DataFrame
reference_data_df = pd.DataFrame(thread_reference.data)
anonymized_data_df = pd.DataFrame(thread_anonymized.data)

# Appliquer K-means et regrouper les données par clusters
ref_grouped_data = apply_kmeans_and_group_by_cluster(reference_data_df, n_clusters)
anon_grouped_data = apply_kmeans_and_group_by_cluster(anonymized_data_df, n_clusters)

# Trouver des correspondances dans les clusters en parallèle
matches = parallel_find_matches(ref_grouped_data, anon_grouped_data, similarity_threshold)

# Organiser les correspondances par semaine
organized_matches_by_week = organize_matches_by_week(matches)

# Sauvegarder le résultat organisé dans un fichier JSON
save_json(organized_matches_by_week, output_json_path)

print(f"Fichier JSON sauvegardé : {output_json_path}")
