import pandas as pd
import random
import string

def generate_token():
    token_length = 10  # Longueur du token
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(token_length))

def main():
    file_path = '../ref.csv'
    df = pd.read_csv(file_path, sep='\t', header=None, names=['id', 'date', 'long', 'lat'])

    print("DataFrame Original:")
    print(df.head())

    # Générer des tokens pour chaque ID unique
    unique_ids = df['id'].unique()
    token_map = {id_: generate_token() for id_ in unique_ids}

    # Conserver le mappage ID-Token pour référence ultérieure
    mapping = token_map.copy()

    # Remplacer les IDs par des tokens dans le DataFrame
    df['id'] = df['id'].apply(lambda x: token_map[x])

    print("\nDataFrame avec ID remplacé par Token:")
    print(df.head())

    # Afficher le mappage (optionnel)
    #print("\nMappage ID-Token:")
    #for id_, token in mapping.items():
    #    print(f"ID Original: {id_}, Token: {token}")

    #exporter la data base
    df.to_csv("ano_ids.csv", index=False, sep='\t')


if __name__ == "__main__":
    main()
