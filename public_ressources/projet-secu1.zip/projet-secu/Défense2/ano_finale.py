import pandas as pd

def reduce_precision(coord, precision):
    """
    Réduit la précision d'une coordonnée géographique.

    Args:
    coord (float): La coordonnée originale (latitude ou longitude).
    precision (int): Le nombre de décimales à conserver.

    Returns:
    float: La coordonnée avec une précision réduite.
    """
    return round(coord, precision)

def main():
    file_path = 'ano_ids_date_time.csv'  
    df = pd.read_csv(file_path, sep='\t', header=0, names=['id', 'date', 'long', 'lat'])

    print("DataFrame Original:")
    print(df.head())

    # Réduction de la précision des coordonnées géographiques
    df['lat'] = df['lat'].apply(lambda x: reduce_precision(x, 3))  # Réduit la précision de la latitude
    df['long'] = df['long'].apply(lambda x: reduce_precision(x, 3))  # Réduit la précision de la longitude

    print("\nDataFrame avec Coordonnées Anonymisées:")
    print(df.head())

    #exporter la data base
    df.to_csv("ano_finale.csv", index=False, sep='\t', header=False)


if __name__ == "__main__":
    main()
