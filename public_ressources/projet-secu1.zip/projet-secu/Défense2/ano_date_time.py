import pandas as pd
from datetime import datetime

def truncate_datetime(date_str):
    # Convertit la chaîne en objet datetime
    date = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    # Tronque la date pour ne garder que l'année, le mois, le jour et l'heure
    truncated_date = datetime(year=date.year, month=date.month, day=date.day, hour=date.hour)
    # Convertit de nouveau en chaîne
    return truncated_date.strftime("%Y-%m-%d %H:00:00")

def main():
    file_path = 'ano_ids.csv'
    df = pd.read_csv(file_path, sep='\t', header=0, names=['id', 'date', 'long', 'lat'])

    print("DataFrame Original:")
    #print(df.head())

    # Appliquer la troncature sur la colonne de date
    df['date'] = df['date'].apply(truncate_datetime)

    print("\nDataFrame avec Dates Tronquées:")
    #print(df.head())
    
    #exporter la data base
    df.to_csv("ano_ids_date_time.csv", index=False, sep='\t')

if __name__ == "__main__":
    main()
