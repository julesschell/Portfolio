import pandas as pd
import random

def anonymize_geo(coord, max_offset=0.0001):
    """
    Ajoute un décalage aléatoire à une coordonnée géographique.

    Args:
    coord (float): La coordonnée originale (latitude ou longitude).
    max_offset (float): Le décalage maximal, en degrés.

    Returns:
    float: La coordonnée anonymisée.
    """
    offset = random.uniform(-max_offset, max_offset)
    return coord + offset

def main():

    file_path = 'anonymize_ids_date_time.csv'

    # Chargement du DataFrame
    df = pd.read_csv(file_path, sep='\t', header=None, names=['id', 'date', 'long', 'lat'])

    # Affichage du DataFrame original
    print("DataFrame Original:")
    print(df.head())

    # Application de l'anonymisation
    df['lat'] = df['lat'].apply(lambda x: anonymize_geo(x))
    df['long'] = df['long'].apply(lambda x: anonymize_geo(x))

    # Affichage du DataFrame anonymisé
    print("\nDataFrame Anonymisé:")
    print(df.head())
    df.to_csv("anonymize_finale.csv", index=False, sep='\t',header=False)

if __name__ == "__main__":
    main()
