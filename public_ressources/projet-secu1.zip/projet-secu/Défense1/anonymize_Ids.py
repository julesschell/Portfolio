import pandas as pd
import random
import string


CHARACTERS_POOL = string.digits

# Classe m pour la conversion en Morse
class m:
    # Dictionnaire pour la conversion de caractères en code Morse
    MORSE_CODE_DICT = {
    #    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.',
    #    'F': '..-.', 'G': '--.', 'H': '....', 'I': '..', 'J': '.---',
    #     'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.', 'O': '---',
    #     'P': '.--.', 'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-',
    #     'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--',
    #     'Z': '--..',

        '0': '-----', '1': '.----', '2': '..---', '3': '...--',
        '4': '....-', '5': '.....', '6': '-....', '7': '--...',
        '8': '---..', '9': '----.'
    }

    @staticmethod
    def stringToMorse(s: str) -> str:
        """
        Convertit une chaîne de caractères en code Morse.

        Args:
            s (str): La chaîne à convertir.

        Returns:
            str: La chaîne convertie en code Morse.
        """
        morse_str = ''
        for char in s.upper():
            if char in m.MORSE_CODE_DICT:
                morse_str += m.MORSE_CODE_DICT[char] + ' '
            else:
                morse_str += '? '  # marque inconnue pour les caractères non pris en charge
        return morse_str.strip()
    def morseToInt(morse: str) -> int:
        """
        Convertit une chaîne en code Morse en un entier.

        Args:
            morse (str): La chaîne en code Morse à convertir.

        Returns:
            int: La valeur entière convertie depuis le code Morse.
        """
        morse_to_char = {v: k for k, v in m.MORSE_CODE_DICT.items()}
        number_str = ''.join(morse_to_char.get(code, '?') for code in morse.split())
        try:
            return int(number_str)
        except ValueError:
            return None  # Retourne None ou une valeur appropriée en cas d'erreur de conversion


# Fonction generator
def generator(group_length:int, nb_characters : int):
    pseudo_id_str = ''.join(random.choice(CHARACTERS_POOL) for _ in range(nb_characters))
    pseudo_id_final = m.stringToMorse(pseudo_id_str)
    return [pseudo_id_final] * group_length


# Fonction generatePseudoIds
def generatePseudoIds(df : pd.DataFrame):
    df['semaine'] = pd.to_datetime(df['date'], format="%Y-%m-%d %H:%M:%S").dt.isocalendar().week
    df['id_x'] = df['id']
    df['id_x'] = df.groupby(['id', 'semaine'])['id_x'].transform(lambda serie : generator(serie.size, nb_characters=5))
    #print(df.groupby(['id', 'semaine'])[['id_x']].first())
    return df[['id_x', 'date', 'long', 'lat']]


# Fonction principale pour tester
def main():
    # charger les data frame
    df_test = pd.read_csv("../ref.csv", sep='\t', header=None, names=['id', 'date', 'long', 'lat'])

    # Affichez le DataFrame original
    print("DataFrame Original:")
    print(df_test)

    # Appliquez la fonction d'anonymisation
    df_anonymized = generatePseudoIds(df_test)

    # Affichez le DataFrame anonymisé
    print("\nDataFrame Anonymisé:")
    print(df_anonymized)

    # reconstruire les IDs
    df_reconstructed = df_anonymized.copy()
    df_reconstructed['id_x'] = df_reconstructed['id_x'].apply(m.morseToInt)

    print("\nDataFrame avec IDs reconstruits:")
    print(df_reconstructed)


    
    df_reconstructed.to_csv("anomymize_Ids.csv", index=False, sep='\t', header=False)


# Exécutez le script principal
if __name__ == "__main__":
    main()
