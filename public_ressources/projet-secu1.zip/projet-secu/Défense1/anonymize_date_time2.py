import pandas as pd
import random
from datetime import datetime, timedelta

def anonymize_datetime(date_str):
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        # Calcul de la date de début et de fin de la semaine actuelle
        start_of_week = date - timedelta(days=date.weekday())
        end_of_week = start_of_week + timedelta(days=6)

        # Générer une nouvelle date dans la même semaine
        while True:
            days_offset = random.randint(-3, 3)
            hours_offset = random.randint(-24, 24)
            minutes_offset = random.randint(-60, 60)
            seconds_offset = random.randint(-60, 60)
            new_date = date + timedelta(days=days_offset, hours=hours_offset, minutes=minutes_offset, seconds=seconds_offset)
            if start_of_week <= new_date <= end_of_week:
                break

        return new_date.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return date_str  # Retourne la chaîne originale en cas d'erreur


def main():
    file_path = 'anomymize_Ids.csv' 

    # Chargement du DataFrame
    df = pd.read_csv(file_path, sep='\t', header=None, names=['id', 'date', 'long', 'lat'])

    # Affichage du DataFrame original
    print("DataFrame Original:")
    print(df)

    # Application de l'anonymisation
    df['date'] = df['date'].apply(anonymize_datetime)

    # Affichage du DataFrame anonymisé
    print("\nDataFrame Anonymisé:")
    print(df)
    
    df.to_csv("anonymize_ids_date_time.csv", index=False, sep='\t', header=False)

if __name__ == "__main__":
    main()

