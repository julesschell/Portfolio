import pandas as pd
import numpy as np
import datetime
import json
from numba import jit
from multiprocessing import Pool


#@jit(nopython=True)
def is_similar(value1, value2, threshold):
    return np.abs(value1 - value2) <= threshold


def load_csv(file_path):
    """Charge les données d'un fichier CSV avec Pandas."""
    df = pd.read_csv(file_path, delimiter='\t', header=None, names=['id', 'date', 'longitude', 'latitude'])

    # Filtrer les lignes avec 'DEL'
    df = df[df['id'] != 'DEL']

    # Convertir les colonnes 'longitude' et 'latitude' en float
    df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')
    df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')

    # Convertir la colonne 'date' en datetime
    df['date'] = pd.to_datetime(df['date'], errors='coerce')

    return df


def find_matches(ref_chunk, anon_chunk, threshold):
    
    # Joindre les DataFrames sur la colonne 'date'
    merged = pd.merge(ref_chunk, anon_chunk, on='date', suffixes=('_ref', '_anon'))

    # Supprimer les lignes où l'ID est "DEL"
    #merged = merged[merged['id_anon'] != 'DEL']

    # Conversion en NumPy arrays
    lat_ref = merged['latitude_ref'].values
    lat_anon = merged['latitude_anon'].values
    long_ref = merged['longitude_ref'].values
    long_anon = merged['longitude_anon'].values

    # Application de la fonction is_similar
    similar_mask = is_similar(lat_ref, lat_anon, threshold) & is_similar(long_ref, long_anon, threshold)
    similar = merged[similar_mask]

    # Créer des dictionnaires pour chaque paire correspondante
    return [{'anonymized': row['id_anon'], 'reference': row['id_ref'], 'date': row['date']} for _, row in similar.iterrows()]

def parallel_find_matches(ref_data, anon_data, threshold, n_processes):
    pool = Pool(n_processes)
    chunksize = max(1, int(len(anon_data) / (n_processes * 1000)))  # Réduire significativement la taille des chunks
    tasks = [(ref_data.iloc[i:i + chunksize], anon_data, threshold) for i in range(0, len(ref_data), chunksize)]
    results = pool.starmap(find_matches, tasks)
    pool.close()
    pool.join()
    return [item for sublist in results for item in sublist]

def organize_matches_by_week(matches, reference_data):
    # Convertir les correspondances en DataFrame
    df_matches = pd.DataFrame(matches)

    # Extraire l'année et la semaine à partir de la date
    df_matches['date'] = pd.to_datetime(df_matches['date'])
    df_matches['year_week'] = df_matches['date'].dt.isocalendar().year.astype(str) + '-' + df_matches['date'].dt.isocalendar().week.astype(str).str.zfill(2)

    # Créer une liste de toutes les semaines requises (semaine 10 à 20)
    weeks_required = [f"2015-{week:02d}" for week in range(10, 21)]

    # Créer un DataFrame de toutes les combinaisons uniques de 'id_ref' et 'year_week'
    ref_ids = reference_data['id'].unique()
    all_combinations = pd.MultiIndex.from_product([ref_ids, weeks_required], names=['reference', 'year_week']).to_frame(index=False)

    # Fusionner avec les correspondances, en remplissant les valeurs manquantes par 'null'
    merged = pd.merge(all_combinations, df_matches, on=['reference', 'year_week'], how='left')
    merged['anonymized'] = merged['anonymized'].fillna('null')

    # Grouper par 'reference' et 'year_week' et trouver le mode (ou 'null')
    grouped = merged.groupby(['reference', 'year_week'])
    mode_df = grouped['anonymized'].agg(lambda x: pd.Series.mode(x)[0]).reset_index()

    # Convertir en dictionnaire organisé
    organized_data = {}
    for _, row in mode_df.iterrows():
        ref_id, year_week, anon_id = row['reference'], row['year_week'], row['anonymized']
        if ref_id not in organized_data:
            organized_data[ref_id] = {}
        # Envelopper l'identifiant anonyme identifié dans un tableau, sauf si c'est 'null'
        organized_data[ref_id][year_week] = [anon_id] if anon_id != 'null' else 'null'

    return organized_data




def save_json(data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(data, file, indent=4)

def main():
    reference_csv_path = 'ref_modified.csv'
    anonymized_csv_path = 'files/frangine2'
    output_json_path = 'jsons/frangine/frangine2.json'
    similarity_threshold = 0.01
    n_processes = 4

    # Charger les données CSV
    reference_data = load_csv(reference_csv_path)
    anonymized_data = load_csv(anonymized_csv_path)

    # Trouver les correspondances
    matches = parallel_find_matches(reference_data, anonymized_data, similarity_threshold, n_processes)

    # Organiser les correspondances par semaine
    organized_matches_by_week = organize_matches_by_week(matches, reference_data)

    # Sauvegarder en format JSON
    save_json(organized_matches_by_week, output_json_path)

    print(f"Fichier JSON sauvegardé : {output_json_path}")

if __name__ == '__main__':
    main()
