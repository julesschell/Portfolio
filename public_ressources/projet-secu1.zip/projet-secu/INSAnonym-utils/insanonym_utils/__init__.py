"""
Public api for python package `INSAnonym-utils`

.. include:: ../docs/README.md
"""
