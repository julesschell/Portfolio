import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def zone_group(df, by=None, round_val=5,on=0.001):
    
    round_fun= lambda x: round(np.mean(x), round_val) if round_val!=0 else np.mean(x)

    df["date"] = pd.to_datetime(df["date"])
    df['Week'] = df['date'].dt.isocalendar().week

    df = df.groupby(by+['longitude', 'latitude'], as_index=False).size()
    df.rename(columns={"size": "Num"}, inplace=True)
    
    temp = df.sort_values("longitude")
    if by is not None:
        temp = temp.groupby(by)
    long_group = temp["longitude"].diff().gt(on).cumsum()
    
    temp = df.sort_values("latitude")
    if by is not None:
        temp = temp.groupby(by)
    lat_group = temp["latitude"].diff().gt(on).cumsum()
    
    temp = [long_group,lat_group]
    if by is not None:
        temp += by
    grouped = df.groupby(temp, as_index=False)
    grouped = grouped.agg(
        Longitude=('longitude', round_fun),
        Latitude=('latitude', round_fun),
        Num=('Num', sum))
 
    grouped.drop(grouped[grouped.Num < 10].index, inplace=True)
    
    return grouped.sort_values(by="Num")

df_anon = pd.read_csv("../../Défense1/anonymize_finale.csv", sep='\t', header=None, names=['id', 'date', 'longitude', 'latitude'])
df_original = pd.read_csv("../../ref.csv", sep='\t', header=None, names=['id', 'date', 'longitude', 'latitude'])

grouped_tra_ori=zone_group(df_original, by=["Week"],round_val=3,on=0.005 )
size_ano=len(df_anon)
df_anon=df_anon[df_anon["id"]!="DEL"]
ratio=len(df_anon)/size_ano
grouped_tra_ano=zone_group(df_anon, by=["Week"],round_val=3,on=0.05 )

grouped_tra_ano.Num=(grouped_tra_ano.Num/ratio).apply(int)

merged=pd.merge(grouped_tra_ori,grouped_tra_ano,on=["Week","Longitude","Latitude"])


count=0
for line in merged.itertuples():
    count+=min(line[5]/line[4],line[4]/line[5])
score=count/len(merged)

print(score)

# Calculer le score d'utilité pour chaque ligne et l'ajouter comme nouvelle colonne
merged['Utility Score'] = merged.apply(lambda row: min(row['Num_x'] / row['Num_y'], row['Num_y'] / row['Num_x']), axis=1)


plt.figure(figsize=(12, 6))
plt.plot(merged.index, merged['Utility Score'], marker='o', linestyle='-', markersize=4)
plt.title('Score utilité de chaque groupe')
plt.xlabel('Groupe')
plt.ylabel('Score Utilité ')
plt.grid(True)
plt.show()


plt.figure(figsize=(14, 6))
# Données originales
plt.subplot(1, 2, 1)
plt.scatter(df_original['longitude'], df_original['latitude'], alpha=0.5, s=1)
plt.title('Original Data')
plt.xlabel('Longitude')
plt.ylabel('Latitude')

# Données anonymisées
plt.subplot(1, 2, 2)
plt.scatter(df_anon['longitude'], df_anon['latitude'], alpha=0.5, s=1, color='r')
plt.title('Anonymized Data')
plt.xlabel('Longitude')
plt.ylabel('Latitude')

plt.tight_layout()
plt.show()
