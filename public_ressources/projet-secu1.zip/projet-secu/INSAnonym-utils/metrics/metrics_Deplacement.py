import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

def create_location_sequence(df, id_col, loc_cols):
    """
    Crée une séquence de localisations pour chaque utilisateur.
    """
    sequences = df.groupby(id_col)[loc_cols].apply(lambda x: x.values.tolist())
    return sequences

def calculate_similarity(seq1, seq2):
    """
    Calcule la similarité entre deux séquences de localisations.
    """
    return cosine_similarity([seq1], [seq2])[0][0]

def main(df_anon, df_original, id_col, loc_cols):
    # Créer des séquences de localisations pour les données anonymisées et originales
    seq_anon = create_location_sequence(df_anon, id_col, loc_cols)
    seq_orig = create_location_sequence(df_original, id_col, loc_cols)

    # Calculer la similarité pour chaque utilisateur
    similarity_scores = {}
    for user_id in seq_anon.index:
        if user_id in seq_orig:
            similarity_scores[user_id] = calculate_similarity(seq_anon[user_id], seq_orig[user_id])

    # Calculer le score moyen de similarité
    avg_similarity = sum(similarity_scores.values()) / len(similarity_scores)

    return avg_similarity

# Exemple d'utilisation
# main(df_anon, df_original, 'id', ['longitude', 'latitude'])
