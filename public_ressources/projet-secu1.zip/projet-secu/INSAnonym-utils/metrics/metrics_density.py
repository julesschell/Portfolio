import pandas as pd

def calculate_density(df, loc_cols, time_col, time_bins):
    """
    Calcule la densité des utilisateurs dans chaque zone et chaque tranche horaire.
    """
    # S'assurer que la colonne de temps est de type datetime
    df[time_col] = pd.to_datetime(df[time_col])

    # Créer des tranches horaires
    df['time_bin'] = pd.cut(df[time_col], bins=time_bins)

    # Calculer la densité
    density = df.groupby(['time_bin'] + loc_cols).size().reset_index(name='count')
    return density


from sklearn.cluster import DBSCAN
import pandas as pd
import numpy as np

def apply_dbscan_clustering(df, loc_cols, eps=0.01, min_samples=10):
    """
    Applique le clustering DBSCAN sur les données géospatiales.

    Arguments:
    df -- DataFrame contenant les données à regrouper.
    loc_cols -- Colonnes contenant les coordonnées géographiques (latitude, longitude).
    eps -- Le rayon maximal entre deux échantillons pour qu'ils soient considérés dans le même voisinage.
    min_samples -- Le nombre minimal d'échantillons dans un voisinage pour qu'un point soit considéré comme un noyau.

    Retourne:
    Le DataFrame avec une nouvelle colonne 'cluster' indiquant l'appartenance au cluster.
    """
    # Extrait les coordonnées géographiques
    coords = df[loc_cols].values

    # Applique DBSCAN
    db = DBSCAN(eps=eps, min_samples=min_samples, algorithm='auto', metric='haversine').fit(np.radians(coords))

    # Ajoute les étiquettes de cluster au DataFrame
    df['cluster'] = db.labels_

    return df

# Usage de la fonction dans le cadre de la métrique de densité
# Assurez-vous que 'df_anon' et 'df_original' sont vos DataFrames contenant les données anonymisées et originales.
# params doit être mis à jour pour inclure 'eps' et 'min_samples' si vous souhaitez utiliser des valeurs différentes des paramètres par défaut.


def compare_density(df_anon, df_original, loc_cols, time_col, time_bins):
    """
    Compare la densité dans les zones à forte fréquentation entre les données anonymisées et originales.
    """
    density_anon = calculate_density(df_anon, loc_cols, time_col, time_bins)
    density_orig = calculate_density(df_original, loc_cols, time_col, time_bins)

    # Fusionner les densités anonymisées et originales pour comparaison
    merged_density = pd.merge(density_orig, density_anon, on=['time_bin'] + loc_cols, suffixes=('_orig', '_anon'))

    # Calculer la différence de densité
    merged_density['density_diff'] = merged_density['count_anon'] - merged_density['count_orig']

    # Évaluer la stabilité temporelle
    stability = merged_density['density_diff'].abs().mean()
    return stability

def main(df_anon_path, df_original_path, loc_cols, time_col, time_bins):
    # Charger les données depuis les chemins de fichiers
    df_anon = pd.read_csv(df_anon_path, sep='\t', header=None, names=['id', 'date', 'longitude', 'latitude'])
    df_original = pd.read_csv(df_original_path, sep='\t', header=None, names=['id', 'date', 'longitude', 'latitude'])
    df_anon = df_anon.loc[df_anon['id'] != "DEL"]
    df_anon[time_col] = pd.to_datetime(df_anon[time_col])
    df_original[time_col] = pd.to_datetime(df_original[time_col])

    # Appeler la fonction compare_density
    stability_score = compare_density(df_anon, df_original, loc_cols, time_col, time_bins)

    return stability_score

# Définir les valeurs de début et de fin
start = '2015-03-04 00:35:16'
end = '2015-03-12 19:29:04'
time_bins = pd.date_range(start, end, freq='H')

# Exemple d'utilisation
stability = main('test.csv', 'test_dataset.csv', ['longitude', 'latitude'], 'date', time_bins)
print("Score de stabilité temporelle :", stability)
