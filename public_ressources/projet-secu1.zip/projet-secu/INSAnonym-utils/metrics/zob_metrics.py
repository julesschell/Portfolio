import pandas as pd
from tqdm import tqdm

def date_metric(df_anon_date, df_original_date, nb_orig_lines, params):
    df = df_anon_date.copy()
    df_original_date_reduced = df_original_date.copy()

    # Convertir les colonnes de date en pandas datetime
    df['date'] = pd.to_datetime(df['date'])
    df_original_date_reduced['date'] = pd.to_datetime(df_original_date_reduced['date'])

    # Vérifier si les semaines sont les mêmes
    if not (df['date'].dt.isocalendar().week == df_original_date_reduced['date'].dt.isocalendar().week).all():
        raise Exception("Weeks must be the same")

    # Initialiser le score
    score = 0

    # Ajout d'une barre de chargement pour l'itération sur les lignes du DataFrame
    for index, row in tqdm(df.iterrows(), total=df.shape[0]):
        day_diff = abs(row['date'].dayofweek - df_original_date_reduced.at[index, 'date'].dayofweek)
        df_score = 3 - day_diff
        if df_score > 0:
            score += df_score

    return score / 3 / nb_orig_lines

def main():
    anonymized_path = 'test.csv'
    original_path = 'test_dataset.csv'

    # Charger les données
    df_anon_date = pd.read_csv(anonymized_path, sep='\t', header=None, names=['id', 'date', 'longitude', 'latitude'])
    df_original_date = pd.read_csv(original_path, sep='\t', header=None, names=['id', 'date', 'longitude', 'latitude'])
    
    # Corriger les noms des colonnes
    df_original_date.columns = ['id', 'date', 'latitude', 'longitude']

    # Vérifier si les datasets ont le même nombre de lignes
    if len(df_anon_date) != len(df_original_date):
        print("Datasets do not have the same number of rows")
    else:
        nb_orig_lines = len(df_original_date)
        score = date_metric(df_anon_date, df_original_date, nb_orig_lines, params=None)
        print(f"Score: {score}")

if __name__ == "__main__":
    main()
