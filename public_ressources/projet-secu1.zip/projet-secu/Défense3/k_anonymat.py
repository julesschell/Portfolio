import pandas as pd

def get_k_anonymity(df, cols):
    """ Calcule le k-anonymat pour le DataFrame en fonction des colonnes spécifiées. """
    group_size = df.groupby(cols).size()
    return group_size.min()

def apply_k_anonymity(df, cols, k):
    """ Applique le k-anonymat en remplaçant les IDs des groupes de taille inférieure à k par 'DEL'. """
    group_size = df.groupby(cols).size()
    valid_groups = group_size[group_size >= k].index

    # Marque les lignes des groupes non valides
    mask = df[cols].apply(tuple, axis=1).isin(valid_groups)
    
    # Remplace les IDs par 'DEL' pour les lignes des groupes non valides
    df.loc[~mask, 'id'] = 'DEL'
    return df

def main():
    file_path = '../ref.csv'
    
    # Lire la DataFrame 
    df = pd.read_csv(file_path, sep='\t', header=None, names=['id', 'date', 'long', 'lat'])

    # Convertir la colonne 'id' en chaîne de caractères pour permettre le remplacement par 'DEL'
    df['id'] = df['id'].astype(str)

    # Colonnes à utiliser pour le k-anonymat
    cols = ['long', 'lat']  

    # Définir la valeur k 
    k = 5

    # Appliquer le k-anonymat
    anonymized_df = apply_k_anonymity(df, cols, k)

    # Afficher le résultat
    print("DataFrame avant l'application du k-anonymat:")
    print(df.head())  # Afficher les premières lignes pour un aperçu
    print("\nDataFrame après l'application du k-anonymat:")
    print(anonymized_df.head())  # De même pour le DataFrame anonymisé

    # Exporter la base de données anonymisée
    anonymized_df.to_csv("anonym_finale2.csv", index=False, sep='\t', header=False)

if __name__ == "__main__":
    main()
