import pandas as pd
import random

file_path = "anonymisation_finale5.csv"
df = pd.read_csv(file_path, sep='\t', header=None, names=['id', 'date', 'long', 'lat'])

# Convertir la colonne 'id' en chaîne de caractères pour permettre le remplacement par 'DEL'
df['id'] = df['id'].astype(str)

# Pourcentage de champs 'id' à remplacer par 'DEL'
percentage_to_replace = 0.1  

# Calcul du nombre de champs 'id' à remplacer
num_ids_to_replace = int(len(df) * percentage_to_replace)

# Sélection aléatoire des indices à remplacer
indices_to_replace = random.sample(range(len(df)), num_ids_to_replace)

# Remplacement des 'id' sélectionnés par 'DEL'
for index in indices_to_replace:
    df.at[index, 'id'] = 'DEL'

print("DataFrame après remplacement aléatoire des champs 'id' par 'DEL' :\n", df)

df.to_csv("anonymisation_finale9.csv", index=False, sep='\t',header=False)
