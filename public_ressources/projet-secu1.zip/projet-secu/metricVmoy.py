import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def haversine(lon1, lat1, lon2, lat2):


    # Convertir les degrés décimaux en radians
    lon1, lat1, lon2, lat2 = map(np.radians, [lon1, lat1, lon2, lat2])
    # Formule Haversine
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    c = 2 * np.arcsin(np.sqrt(a))
    r = 6371000  # Rayon de la Terre en mètres
    return c * r


def process_chunk(chunk):
    # Nettoyage des données
    chunk.replace('DEL', np.nan, inplace=True)
    chunk.dropna(subset=['longitude', 'latitude', 'date'], inplace=True)
    chunk['longitude'] = pd.to_numeric(chunk['longitude'], errors='coerce')
    chunk['latitude'] = pd.to_numeric(chunk['latitude'], errors='coerce')
    chunk['date'] = pd.to_datetime(chunk['date'], errors='coerce')
   
    # Ajout de l'information temporelle
    chunk['week'] = chunk['date'].dt.isocalendar().week
    chunk['year'] = chunk['date'].dt.year
   
    # Assurez-vous de trier les données pour garantir la séquence temporelle
    chunk.sort_values(by=['id', 'date'], inplace=True)
   
    # Calcul des distances et des vitesses pour des enregistrements consécutifs
    chunk['shifted_latitude'] = chunk.groupby('id')['latitude'].shift(-1)
    chunk['shifted_longitude'] = chunk.groupby('id')['longitude'].shift(-1)
    chunk['distance'] = haversine(chunk['longitude'], chunk['latitude'], chunk['shifted_longitude'], chunk['shifted_latitude'])
    chunk['time_diff'] = (chunk.groupby('id')['date'].shift(-1) - chunk['date']).dt.total_seconds()
   
    # Filtrer les enregistrements avec des différences de temps non valides ou nulles
    chunk = chunk[(chunk['time_diff'] > 0) & (~chunk['distance'].isnull())]
   
    # Calcul de la vitesse en m/s
    chunk['speed'] = chunk['distance'] / chunk['time_diff']
   
    # Retourner le morceau traité
    return chunk[['id', 'year', 'week', 'speed']]


def aggregate_speeds(file_path, chunk_size=10000):
    aggregated_speeds = pd.DataFrame()
    for chunk in pd.read_csv(file_path, sep='\t', header=None, names=['id', 'date', 'longitude', 'latitude'], chunksize=chunk_size):
        processed_chunk = process_chunk(chunk)
        aggregated_speeds = pd.concat([aggregated_speeds, processed_chunk])
   
    # Agrégation finale pour obtenir la vitesse moyenne par id et semaine
    final_speeds = aggregated_speeds.groupby(['id', 'year', 'week'])['speed'].mean().reset_index()
    return final_speeds


def calculate_score(average_speeds, v_ref=1.374970075149441, max_score=1.0):
    average_speeds['score'] = average_speeds['speed'].apply(lambda x: max(0, max_score - (abs(x - v_ref) / v_ref)))
    return average_speeds




# Chemin vers le fichier CSV
file_path = 'testBDD'


# Exécution de l'agrégation et du calcul de la vitesse moyenne
final_speeds = aggregate_speeds(file_path)


# Calcul des scores individuels
final_scores = calculate_score(final_speeds)


# Calcul du score général comme la moyenne des scores individuels
score_general = final_scores['score'].mean()


#Affichage du score général
print(f"Score général basé sur la vitesse moyenne par id et semaine: {score_general:.2f}")